export class CreateUserDTO {
  pseudo: string;
  password: string;
}
