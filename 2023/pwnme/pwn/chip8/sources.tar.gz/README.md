# Installation

## Steps
- `git clone https://github.com/LakshyAAAgrawal/chip8emu`
- `cd chip8emu`
- `git apply ../chall.patch`
- `make`
- `./bin/c8emu <rom>`