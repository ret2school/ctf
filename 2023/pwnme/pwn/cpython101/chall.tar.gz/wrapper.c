#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdint.h>
#include <sys/stat.h>
#include <fcntl.h>

#define MAX_CODE_SIZE	25000
#define MAX_LINE_LEN	0x200
#define SCRIPT_PATH_LEN	0x20
#define SCRIPT_PATH		"/tmp"

// gcc -static -o wrapper wrapper.c

char * get_path()
{
	char *path;
	uint64_t rand;
	int fd;

	fd = open("/dev/urandom", O_RDONLY);

	if (fd < 0)
		exit(-1);

	if ( read(fd, &rand, sizeof(rand)) != sizeof(rand) )
		exit(-1);

	close(fd);

	path = malloc(SCRIPT_PATH_LEN * sizeof(char));

	if (!path)
		exit(-1);

	snprintf(path, SCRIPT_PATH_LEN, "%s/%lx.py", SCRIPT_PATH, rand);

	return path;
}
/*
void apply_pre_commands(int fd)
{
	for (int i = 0; i < (sizeof(pre_commands) / sizeof(char *)); i++)
	{
		write(fd, pre_commands[i], strlen(pre_commands[i]));
	}
}
*/
void main()
{
	char *path;
	int total_length = 0;
	int nb, fd;

	char *exec_argv[3] = {
		"/usr/bin/python3",
		"-u",
		""
	};

	char *exec_envp[] = {
		"LD_PRELOAD=./hook.so"
	};

	char *line = malloc(MAX_LINE_LEN * sizeof(char));

	if (!line)
		exit(-1);

	path = get_path();

	if ((fd = open(path, O_RDWR | O_CREAT, S_IXUSR | S_IREAD)) < 0)
		exit(-1);

	while (1) {
		memset(line, 0, MAX_LINE_LEN);
		write(1, "> ", 2);

		nb = read(STDIN_FILENO, line, MAX_LINE_LEN);

		total_length += nb;

		if (total_length > MAX_CODE_SIZE)
			goto end;

		if (!strcmp(line, "EOF\n"))
			break;

		write(fd, line, nb);
	}

	exec_argv[2] = path;
	exec_argv[3] = NULL;

	alarm(25);

	execve("/usr/bin/python3", exec_argv, exec_envp);

end:
	close(fd);
}
