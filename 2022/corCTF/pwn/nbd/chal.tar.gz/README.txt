Source code of nbd-client binary can be found here:
    https://github.com/NetworkBlockDevice/nbd/releases/tag/nbd-3.24
